package entities;public class Wallet {
}
