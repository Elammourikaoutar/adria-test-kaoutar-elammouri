<<<<<<< HEAD
# kaoutar-elammouri-enset-adria-test
CAPTURE

this is the architecture of our microservices project

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/b1a393d9-215d-469b-a671-70bd53b15c56)
=======
# adria-test-kaoutar-elammouri
CAPTURE


![image](https://github.com/Elammourikaoutar/adria-test-kaoutar-elammouri/assets/106027819/b84e8a1b-9107-4868-a2fb-88e1e80279a4)


This is the architecture of our microservices project

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/615b1257-f56a-4507-8b97-cb1dfc737419)

This is the architecture of SERVICE-WALLET

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/be172019-d39b-45d5-aa31-ebcf1eb9d834)

This is the architecture of TRANSFERT-WALLET



![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/ae46328c-0099-437f-9015-8fd139d557d2)

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/4dc4c31e-5613-48ae-9296-23987c16ab41)

This is wallet database in H2 console

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/db67bf29-1b0c-4f84-b147-9d36f779640e)

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/cdc46979-dc1c-486d-b259-1544a3a497c2)

Discovery service architecture and test

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/4fdb1a9d-175b-4b8e-a868-030c480bff6e)

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/4d43f363-d73b-49b1-952d-a129cb67f33f)

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/9bb92393-ba12-4bf7-8d6a-807c109551ff)

![image](https://github.com/Elammourikaoutar/kaoutar-elammouri-enset-adria-test/assets/106027819/fd51b4c5-cb04-472e-89b2-a9f39fe87710)




Gateway microservice and yml properties


>>>>>>> 8faf7e9 (Create README.md)
