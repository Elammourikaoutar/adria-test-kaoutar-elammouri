package ma.enset.walletservice;

import ma.enset.walletservice.entities.Wallet;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import ma.enset.walletservice.repository.WalletRepository;

import java.util.Date;

@SpringBootApplication
public class WalletServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(WalletServiceApplication.class, args);
    }
    @Bean
    CommandLineRunner start(WalletRepository walletRepository, RepositoryRestConfiguration repositoryRestConfiguration){
        repositoryRestConfiguration.exposeIdsFor(Wallet.class);
        return  args ->{
            walletRepository.save(new Wallet(null, 15.0, "currency", new Date(), null));
            walletRepository.save(new Wallet(null, 145.12, "currency", new Date(), null));
            walletRepository.save(new Wallet(null, 10.15, "currency", new Date(), null));
            walletRepository.findAll().forEach(
                    c->{
                        System.out.println(c.toString());
                    }
            );
        };
    }


}
