package ma.enset.transferservice;

public enum TransferStatus {
    PENDING,
    VALIDATED,
    REJECTED
}
