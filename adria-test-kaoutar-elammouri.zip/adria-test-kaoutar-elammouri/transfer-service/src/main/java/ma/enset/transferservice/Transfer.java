package ma.enset.transferservice;

import jakarta.persistence.*;
import ma.enset.walletservice.entities.Wallet;

import java.math.BigDecimal;
import java.util.Date;

@Entity
public class Transfer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Date date;

    @ManyToOne
    @JoinColumn(name = "source_wallet_id")
    private Wallet sourceWallet;

    @ManyToOne
    @JoinColumn(name = "destination_wallet_id")
    private Wallet destinationWallet;

    private Double amount;
    private TransferStatus status;
    // Getter and Setter methods
}

