package entities;public class Client {
}
